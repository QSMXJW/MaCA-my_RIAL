
import torch
import torch.nn as nn
import numpy as np


class ActionNet(nn.Module):
    def __init__(self, n_actions):
        super(ActionNet, self).__init__()
        self.conv1 = nn.Sequential(     # 100 * 100 * 3
            nn.Conv2d(
                in_channels=5,
                out_channels=16,
                kernel_size=5,
                stride=1,
                padding=2,
            ),
            nn.ReLU(),
            nn.MaxPool2d(2),
        )
        self.conv2 = nn.Sequential(     # 50 * 50 * 16
            nn.Conv2d(16, 32, 5, 1, 2),
            nn.ReLU(),
            nn.MaxPool2d(2),            # 25 * 25 * 32
        )
        self.info_fc = nn.Sequential(
            nn.Linear(3, 256),
            nn.Tanh(),
        )
        self.feature_fc = nn.Sequential(    # 25 * 25 * 32 + 256
            nn.Linear((25 * 25 * 32 + 256 + 1 + 1 + 1024), 512),
            nn.ReLU(),
        )
        self.decision_fc = nn.Linear(512, n_actions)

        self.feature_mg1 = nn.Sequential(
            nn.Linear(256*4, 128),
            nn.ReLU(),
        )
        self.feature_mg2 = nn.Sequential(
            nn.Linear(128, 256),
            nn.ReLU(),
        )
        self.feature_mg3 = nn.Sequential(
            nn.Linear(256, 512),
            nn.ReLU(),
        )
        self.feature_mg4 = nn.Sequential(
            nn.Linear(512, 1024),
            nn.ReLU(),
        )
        self.feature_mg5 = nn.Sequential(
            nn.Linear(1024, 2048),
            nn.ReLU(),
        )
        self.feature_mg6 = nn.Sequential(
            nn.Linear(2048, 1024),
            nn.ReLU(),
        )

    def forward(self, img, info, pre_action, message, index):
        img_feature = self.conv1(img)
        img_feature = self.conv2(img_feature)
        info_feature = self.info_fc(info)

        message_feature = self.feature_mg1(message)
        message_feature = self.feature_mg2(message_feature)
        message_feature = self.feature_mg3(message_feature)
        message_feature = self.feature_mg4(message_feature)
        message_feature = self.feature_mg5(message_feature)
        message_feature = self.feature_mg6(message_feature)
        combined = torch.cat((img_feature.view(img_feature.size(0), -1), info_feature.view(info_feature.size(0), -1)),
                             dim=1)

        # print(message_feature.shape, index.shape, pre_action.shape)
        combined = torch.cat((message_feature.view(message_feature.size(0), -1), combined), dim=1)
        k = np.zeros((1, 2), dtype=float)
        k[0, 0] = index
        k[0, 1] = pre_action
        k = torch.FloatTensor(k).cuda()
        combined = torch.cat((k.view(k.size(0), -1), combined), dim=1)

        feature = self.feature_fc(combined)
        action = self.decision_fc(feature)
        return action


class MessageNet(nn.Module):
    def __init__(self, n_actions):
        super(MessageNet, self).__init__()
        self.f1 = nn.Sequential(
            nn.Linear(n_actions, 128),
            nn.ReLU(),
        ).cuda()
        self.f2 = nn.Sequential(
            nn.Linear(128, 256),
            nn.ReLU(),
        ).cuda()
        self.f3 = nn.Sequential(
            nn.Linear(64, 32),
            nn.ReLU(),
        ).cuda()
        self.f4 = nn.Sequential(
            nn.Linear(32, 16),
            nn.ReLU(),
        ).cuda()
        self.f5 = nn.Sequential(
            nn.Linear(16, 8),
            nn.ReLU(),
        ).cuda()
        self.f6 = nn.Sequential(
            nn.Linear(8, 4),
            nn.ReLU(),
        ).cuda()

    def forward(self, action_value):
        if torch.cuda.is_available():
            x = action_value.cuda()

        x = self.f1(x).cuda()
        x = self.f2(x).cuda()
        # x = self.f3(x).cuda()
        # x = self.f4(x).cuda()
        # x = self.f5(x).cuda()
        # x = self.f6(x).cuda()
        return x
