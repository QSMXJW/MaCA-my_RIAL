#! /usr/bin/env python
# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import numpy as np
import copy

from train.my_Rial.rial_net import ActionNet
from train.my_Rial.rial_net import MessageNet


class RLFighter:
    def __init__(
            self,
            n_actions,
            learning_rate=0.01,
            reward_decay=0.9,
            e_greedy=0.9,
            replace_target_iter=10000,
            e_greedy_increment=0.03,
            output_graph=False,
    ):
        self.n_actions = n_actions
        self.lr = learning_rate
        self.gamma = reward_decay
        self.epsilon_max = e_greedy
        self.replace_target_iter = replace_target_iter
        self.epsilon_increment = e_greedy_increment
        self.epsilon = 0 if e_greedy_increment is not None else self.epsilon_max

        self.gpu_enable = torch.cuda.is_available()

        # total learning step
        self.learn_step_counter = 0

        self.cost_his = []
        self.action_eval_net, self.action_target_net = ActionNet(self.n_actions), ActionNet(self.n_actions)
        self.message_eval_net, self.message_target_net = MessageNet(self.n_actions), MessageNet(self.n_actions)
        if self.gpu_enable:
            print('GPU Available!!')
            self.action_eval_net = self.action_eval_net.cuda()
            self.action_target_net = self.action_target_net.cuda()
            self.message_eval_net = self.message_eval_net.cuda()
            self.message_target_net = self.message_target_net.cuda()

        self.loss_func = nn.MSELoss()
        # self.optimizer = torch.optim.Adam(self.eval_net.parameters(), lr=self.lr)
        self.optimizer = torch.optim.RMSprop(self.action_eval_net.parameters(), lr=self.lr)

        self.pre_message = np.random.rand(10, 256)
        self.pre_action = np.zeros(10, dtype=np.int32)
        self.now_message = np.zeros((10, 256), dtype=np.float32)
        self.now_action = np.zeros(10, dtype=np.int32)
        self.select = np.random.rand(4, 256)

    def update_list(self):
        self.pre_action = copy.deepcopy(self.now_action)
        self.pre_message = copy.deepcopy(self.now_message)

    '''
        1.从pre_action和pre_message中选择合适的信息，记为u和m
        2.将u、m、img、info、index送给Action_Net，得到action_value
        3.将action_value送给Message_Net得到message，处理action_value得到action值
        4.将message和action存入now_message和now_action
        5.返回action值
    '''
    def choose_action(self, img_obs, info_obs, index):

        # 100*100*5;100*100表示地图，5表示每个地图格子有5种信息，分别是主动探测到的敌方id、敌方类型、友方标记、被动探测到的敌方id、敌方类型
        img_obs = torch.unsqueeze(torch.FloatTensor(img_obs), 0)
        info_obs = torch.unsqueeze(torch.FloatTensor(info_obs), 0) # 航向、短程导弹数量、中远程导弹数量

        pre_message = copy.deepcopy(self.pre_message)
        pre_action = copy.deepcopy(self.pre_action)

        pre_message = np.delete(pre_message, index, axis=0)

        n = np.random.randint(0, 9)
        a = np.vstack((pre_message[n % 9], pre_message[2*n % 9]))
        a = np.vstack((a, pre_message[3 * n % 9]))
        pre_message = np.vstack((a, pre_message[4 * n % 9]))
        self.select = copy.deepcopy(pre_message)
        pre_message = pre_message.reshape(1, -1)
        pre_message = torch.unsqueeze(torch.FloatTensor(pre_message), 0)

        pre_action = pre_action[index]

        if self.gpu_enable:
            img_obs = img_obs.cuda()
            info_obs = info_obs.cuda()
            pre_message = pre_message.cuda()

        if np.random.uniform() < self.epsilon:
            actions_value = self.action_eval_net(img_obs, info_obs, pre_action, pre_message, index)
            action = torch.max(actions_value, 1)[1]

            mg = self.message_eval_net(actions_value)

            data = str(pre_action)+'\n'+str(pre_message)+'\n'+str(index)+'\n\n'
            file = open('input.txt', 'a')
            file.write(data)
            file.close()

            if self.gpu_enable:
                action = action.cpu()
                mg = mg.cpu()
            action = action.numpy()
            mg = mg.detach().numpy()
            self.now_action[index] = action
            self.now_message[index] = mg
        else:
            action = np.zeros(1, dtype=np.int32)
            mg = np.random.rand(1, 256)
            action[0] = np.random.randint(0, self.n_actions)
            self.now_action[index] = action
            self.now_message[index] = mg
        return action

    def learn(self, img_obs, info_obs, n_img_obs, n_info_obs, reward, index):
        # check to replace target parameters
        if self.learn_step_counter % self.replace_target_iter == 0:
            self.action_target_net.load_state_dict(self.action_eval_net.state_dict())
            self.message_target_net.load_state_dict(self.message_eval_net.state_dict())
            print('\ntarget_params_replaced\n')
            step_counter_str = '%09d' % self.learn_step_counter
            torch.save(self.action_target_net.state_dict(), 'model/my_rial_action/model_' + step_counter_str + '.pkl')
            torch.save(self.message_target_net.state_dict(), 'model/my_rial_message/model_' + step_counter_str + '.pkl')

        pre_message = copy.deepcopy(self.select)
        pre_action = copy.deepcopy(self.pre_action)

        pre_message = pre_message.reshape(1, -1)
        pre_message = torch.unsqueeze(torch.FloatTensor(pre_message), 0)
        pre_action = pre_action[index]

        if self.gpu_enable:
            img_obs = torch.unsqueeze(torch.FloatTensor(img_obs), 0).cuda()
            info_obs = torch.unsqueeze(torch.FloatTensor(info_obs), 0).cuda()
            n_img_obs = torch.unsqueeze(torch.FloatTensor(n_img_obs), 0).cuda()
            n_info_obs = torch.unsqueeze(torch.FloatTensor(n_info_obs), 0).cuda()
            pre_message = pre_message.cuda()

        q_eval = self.action_eval_net(img_obs, info_obs, pre_action, pre_message, index)  # shape (batch, 1)
        q_next = self.action_target_net(n_img_obs, n_info_obs, pre_action, pre_message, index).detach()  # detach from graph, don't backpropagate
        q_target = reward + self.gamma * q_next.max(1)[0].view(1, 1)  # shape (batch, 1)

        q_eval_m = self.message_eval_net(q_eval)  # shape (batch, 1)
        q_next_m = self.message_target_net(q_next).detach()  # detach from graph, don't backpropagate
        q_target_m = reward + self.gamma * q_next_m.max(1)[0].view(1, 1)

        loss_m = self.loss_func(q_eval_m.max(1)[0].view(1, 1), q_target_m)
        loss_a = self.loss_func(q_eval.max(1)[0].view(1, 1), q_target)

        self.optimizer.zero_grad()
        loss_a.backward(retain_graph=True)
        loss_m.backward()
        self.optimizer.step()

        # increasing epsilon
        self.epsilon = self.epsilon + self.epsilon_increment if self.epsilon < self.epsilon_max else self.epsilon_max
        self.learn_step_counter += 1
